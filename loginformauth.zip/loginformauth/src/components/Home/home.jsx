import { useNavigate } from "react-router-dom";
import { useEffect } from "react";
import { Loader } from "@googlemaps/js-api-loader";
import "./home.css";
import Header from "../Header/header";
import Sidebar from "../Sidebar/sidebar";
import Map from "../Maps/map";

const Home = ({ setIsAuthenticated }) => {
    const navigate = useNavigate();

    const logout = () => {
        setIsAuthenticated(false);
        navigate("/login");
    };

    return (
        <div className="home">
            <Header />
            <div className="main-screen">
                <Sidebar />
                <Map />
            </div>
            {/* <h2>Welcome to Searce</h2>
            <button onClick={logout}>Logout</button>
            <div id="map"></div> */}
        </div>
    );
};

export default Home;
